# Introduction

This project contains a collection of SMTs (single message transforms) for use with Kafka Connect.

## Examples

Sample configurations can be found in the [config](config/) directory.
